#parse("C File Header.h")

#[[
#include "LindenbergResearch.hpp"
#include "LRModel.hpp"
]]#

using namespace rack;
using namespace lrt;

struct ${NAME}Widget;

struct $NAME : LRModule {
    enum ParamIds {
        NUM_PARAMS
    };
    enum InputIds {
        NUM_INPUTS
    };
    enum OutputIds {
        NUM_OUTPUTS
    };
    enum LightIds {
        NUM_LIGHTS
    };
    
    ${NAME}Widget *reflect;

    ${NAME}() : LRModule(NUM_PARAMS, NUM_INPUTS, NUM_OUTPUTS, NUM_LIGHTS) {}
    
    void process(const ProcessArgs &args) override;
};


/**
 * @brief $NAME
 */
struct ${NAME}Widget : LRModuleWidget {
    ${NAME}Widget($NAME *module);
};


${NAME}Widget::${NAME}Widget($NAME *module) : LRModuleWidget(module) {
    panel->addVariant(LRGestaltType::DARK, APP->window->loadSvg(asset::plugin(pluginInstance, "res/panels/${NAME}.svg")));
    panel->addVariant(LRGestaltType::LIGHT, APP->window->loadSvg(asset::plugin(pluginInstance, "res/panels/${NAME}Light.svg")));
    panel->addVariant(LRGestaltType::AGED, APP->window->loadSvg(asset::plugin(pluginInstance, "res/panels/${NAME}Aged.svg")));

    panel->init();
    box.size = panel->box.size;
    
     // reflect module widget
    if (!isPreview) module->reflect = this;
}

void ${NAME}::process(const ProcessArgs &args) {
    // +++ DSP CODE +++
}

// create model for VCV
Model *model${NAME} = createModel<$NAME, ${NAME}Widget>("${NAME}");
